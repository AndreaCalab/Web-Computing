--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Italian_Italy.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: progetto; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA progetto;


ALTER SCHEMA progetto OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: asta; Type: TABLE; Schema: progetto; Owner: postgres
--

CREATE TABLE progetto.asta (
    immobile character varying NOT NULL,
    codice character varying NOT NULL,
    offerta_di_base bigint NOT NULL,
    offerta_attuale bigint,
    stato_asta character varying NOT NULL,
    vincitore character varying,
    data_di_scadenza character varying
);


ALTER TABLE progetto.asta OWNER TO postgres;

--
-- Name: immobile; Type: TABLE; Schema: progetto; Owner: postgres
--

CREATE TABLE progetto.immobile (
    categoria character varying NOT NULL,
    descrizione character varying NOT NULL,
    prezzo bigint NOT NULL,
    metri_quadri bigint NOT NULL,
    posizione character varying NOT NULL,
    id character varying NOT NULL,
    proprietario character varying NOT NULL
);


ALTER TABLE progetto.immobile OWNER TO postgres;

--
-- Name: messaggio; Type: TABLE; Schema: progetto; Owner: postgres
--

CREATE TABLE progetto.messaggio (
    id character varying NOT NULL,
    mittente character varying NOT NULL,
    destinatario character varying NOT NULL,
    oggetto character varying NOT NULL,
    operazione character varying NOT NULL,
    messaggio character varying
);


ALTER TABLE progetto.messaggio OWNER TO postgres;

--
-- Name: recensione; Type: TABLE; Schema: progetto; Owner: postgres
--

CREATE TABLE progetto.recensione (
    id character varying NOT NULL,
    utente character varying NOT NULL,
    immobile character varying NOT NULL,
    descrizione character varying NOT NULL
);


ALTER TABLE progetto.recensione OWNER TO postgres;

--
-- Name: utente; Type: TABLE; Schema: progetto; Owner: postgres
--

CREATE TABLE progetto.utente (
    tipo character varying NOT NULL,
    email character varying NOT NULL,
    password character varying NOT NULL,
    username character varying NOT NULL,
    nome character varying NOT NULL,
    cognome character varying NOT NULL,
    banned character varying
);


ALTER TABLE progetto.utente OWNER TO postgres;

--
-- Data for Name: asta; Type: TABLE DATA; Schema: progetto; Owner: postgres
--

COPY progetto.asta (immobile, codice, offerta_di_base, offerta_attuale, stato_asta, vincitore, data_di_scadenza) FROM stdin;
\.
COPY progetto.asta (immobile, codice, offerta_di_base, offerta_attuale, stato_asta, vincitore, data_di_scadenza) FROM '$$PATH$$/3358.dat';

--
-- Data for Name: immobile; Type: TABLE DATA; Schema: progetto; Owner: postgres
--

COPY progetto.immobile (categoria, descrizione, prezzo, metri_quadri, posizione, id, proprietario) FROM stdin;
\.
COPY progetto.immobile (categoria, descrizione, prezzo, metri_quadri, posizione, id, proprietario) FROM '$$PATH$$/3356.dat';

--
-- Data for Name: messaggio; Type: TABLE DATA; Schema: progetto; Owner: postgres
--

COPY progetto.messaggio (id, mittente, destinatario, oggetto, operazione, messaggio) FROM stdin;
\.
COPY progetto.messaggio (id, mittente, destinatario, oggetto, operazione, messaggio) FROM '$$PATH$$/3359.dat';

--
-- Data for Name: recensione; Type: TABLE DATA; Schema: progetto; Owner: postgres
--

COPY progetto.recensione (id, utente, immobile, descrizione) FROM stdin;
\.
COPY progetto.recensione (id, utente, immobile, descrizione) FROM '$$PATH$$/3357.dat';

--
-- Data for Name: utente; Type: TABLE DATA; Schema: progetto; Owner: postgres
--

COPY progetto.utente (tipo, email, password, username, nome, cognome, banned) FROM stdin;
\.
COPY progetto.utente (tipo, email, password, username, nome, cognome, banned) FROM '$$PATH$$/3355.dat';

--
-- Name: asta asta_pk; Type: CONSTRAINT; Schema: progetto; Owner: postgres
--

ALTER TABLE ONLY progetto.asta
    ADD CONSTRAINT asta_pk PRIMARY KEY (codice);


--
-- Name: immobile immobile_pk; Type: CONSTRAINT; Schema: progetto; Owner: postgres
--

ALTER TABLE ONLY progetto.immobile
    ADD CONSTRAINT immobile_pk PRIMARY KEY (id);


--
-- Name: messaggio messaggio_pk; Type: CONSTRAINT; Schema: progetto; Owner: postgres
--

ALTER TABLE ONLY progetto.messaggio
    ADD CONSTRAINT messaggio_pk PRIMARY KEY (id);


--
-- Name: recensione recensione_pk; Type: CONSTRAINT; Schema: progetto; Owner: postgres
--

ALTER TABLE ONLY progetto.recensione
    ADD CONSTRAINT recensione_pk PRIMARY KEY (id);


--
-- Name: utente utenti_pk; Type: CONSTRAINT; Schema: progetto; Owner: postgres
--

ALTER TABLE ONLY progetto.utente
    ADD CONSTRAINT utenti_pk PRIMARY KEY (username);


--
-- PostgreSQL database dump complete
--

